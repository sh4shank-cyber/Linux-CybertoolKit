"""
Shared helpers for the CyberPatriot Linux toolkit.
Standard library only -- these scripts need to run on a competition
image that usually has no internet access, so nothing here may
require pip install.
"""
import json
import os
import subprocess
import sys
from datetime import datetime

# ---- severity levels -------------------------------------------------
HIGH = "HIGH"
MED = "MEDIUM"
LOW = "LOW"
INFO = "INFO"

_ORDER = {HIGH: 0, MED: 1, LOW: 2, INFO: 3}

_COLORS = {
    HIGH: "\033[91m",   # red
    MED: "\033[93m",    # yellow
    LOW: "\033[96m",    # cyan
    INFO: "\033[90m",   # grey
}
_RESET = "\033[0m"
_BOLD = "\033[1m"


def use_color():
    return sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def finding(severity, title, detail=""):
    """Build one finding dict. Every check module returns a list of these."""
    return {"severity": severity, "title": title, "detail": detail}


def sort_findings(findings):
    return sorted(findings, key=lambda f: _ORDER.get(f["severity"], 9))


def run_cmd(args, timeout=15):
    """Run a command, return (returncode, stdout, stderr). Never raises."""
    try:
        proc = subprocess.run(
            args, capture_output=True, text=True, timeout=timeout
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 127, "", f"{args[0]}: not found"
    except subprocess.TimeoutExpired:
        return 124, "", f"{' '.join(args)}: timed out"
    except Exception as e:  # noqa: BLE001 - checks must never crash the run
        return 1, "", str(e)


def is_root():
    return os.geteuid() == 0


def load_config(name, default):
    """Load a JSON file from config/, falling back to `default` if missing
    or invalid so a check never hard-fails just because a student hasn't
    filled in that config file yet."""
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    path = os.path.join(here, "config", name)
    if not os.path.exists(path):
        return default
    try:
        with open(path) as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError):
        return default


def print_findings(check_name, findings):
    findings = sort_findings(findings)
    color = use_color()
    header = f"== {check_name} =="
    print(_BOLD + header + _RESET if color else header)
    if not findings:
        print("  (nothing to report)")
        return
    for f in findings:
        tag = f["severity"]
        prefix = f"{_COLORS[tag]}[{tag}]{_RESET}" if color else f"[{tag}]"
        print(f"  {prefix} {f['title']}")
        if f["detail"]:
            for line in str(f["detail"]).splitlines():
                print(f"        {line}")
    print()


def timestamp():
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


def require_root_notice(check_name):
    return finding(
        INFO,
        "Run as root for a complete picture",
        f"{check_name} skipped some root-only checks. Re-run with sudo.",
    )
