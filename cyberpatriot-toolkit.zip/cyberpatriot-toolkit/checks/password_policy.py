"""
password_policy.py -- checks password aging (/etc/login.defs) and
complexity enforcement (pwquality/cracklib via PAM).

Baseline defaults below are typical CyberPatriot-reasonable values;
adjust MIN_LEN / MAX_DAYS if the scenario README says otherwise.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils

MIN_LEN = 8
MAX_DAYS = 90
MIN_DAYS = 1
WARN_AGE = 7

PAM_PASSWORD_FILES = [
    "/etc/pam.d/common-password",   # Debian/Ubuntu
    "/etc/pam.d/system-auth",       # RHEL/CentOS/Fedora
    "/etc/pam.d/password-auth",
]


def _parse_login_defs():
    values = {}
    if not os.path.exists("/etc/login.defs"):
        return values
    with open("/etc/login.defs") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"^(PASS_MAX_DAYS|PASS_MIN_DAYS|PASS_MIN_LEN|PASS_WARN_AGE)\s+(\d+)", line)
            if m:
                values[m.group(1)] = int(m.group(2))
    return values


def _parse_pwquality():
    for path in ("/etc/security/pwquality.conf",):
        if not os.path.exists(path):
            continue
        values = {}
        with open(path) as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                m = re.match(r"^(minlen|dcredit|ucredit|lcredit|ocredit|retry|minclass)\s*=\s*(-?\d+)", line)
                if m:
                    values[m.group(1)] = int(m.group(2))
        return values
    return None


def _pam_uses_quality_module():
    for path in PAM_PASSWORD_FILES:
        if not os.path.exists(path):
            continue
        with open(path) as fh:
            content = fh.read()
        if "pam_pwquality.so" in content or "pam_cracklib.so" in content:
            return True, path
        return False, path
    return None, None


def check():
    findings = []

    defs = _parse_login_defs()
    if not defs:
        findings.append(utils.finding(
            utils.MED, "/etc/login.defs missing or unreadable",
            "Cannot verify password aging policy.",
        ))
    else:
        max_days = defs.get("PASS_MAX_DAYS")
        if max_days is None or max_days > MAX_DAYS or max_days <= 0:
            findings.append(utils.finding(
                utils.MED, f"PASS_MAX_DAYS is {max_days}, expected <= {MAX_DAYS}",
                "Passwords should expire on a schedule. Edit /etc/login.defs.",
            ))
        min_days = defs.get("PASS_MIN_DAYS")
        if min_days is None or min_days < MIN_DAYS:
            findings.append(utils.finding(
                utils.LOW, f"PASS_MIN_DAYS is {min_days}, expected >= {MIN_DAYS}",
                "Without a minimum age, users can cycle back to an old password immediately.",
            ))
        warn = defs.get("PASS_WARN_AGE")
        if warn is None or warn < WARN_AGE:
            findings.append(utils.finding(
                utils.LOW, f"PASS_WARN_AGE is {warn}, expected >= {WARN_AGE}",
            ))

    pwq = _parse_pwquality()
    if pwq is None:
        findings.append(utils.finding(
            utils.MED, "No pwquality.conf found",
            "Password complexity may not be enforced. Install libpam-pwquality and configure it.",
        ))
    else:
        minlen = pwq.get("minlen")
        if minlen is None or minlen < MIN_LEN:
            findings.append(utils.finding(
                utils.HIGH, f"pwquality minlen is {minlen}, expected >= {MIN_LEN}",
            ))
        for opt, label in (("dcredit", "digit"), ("ucredit", "uppercase"),
                            ("lcredit", "lowercase"), ("ocredit", "special char")):
            val = pwq.get(opt)
            if val is None or val >= 0:
                findings.append(utils.finding(
                    utils.LOW, f"pwquality {opt} not requiring a {label}",
                    f"Current value: {val}. Negative values require at least that many.",
                ))

    used, pam_path = _pam_uses_quality_module()
    if used is None:
        findings.append(utils.finding(
            utils.MED, "No PAM password file found",
            "Checked: " + ", ".join(PAM_PASSWORD_FILES),
        ))
    elif used is False:
        findings.append(utils.finding(
            utils.HIGH, f"PAM complexity module not enabled in {pam_path}",
            "pam_pwquality.so / pam_cracklib.so not referenced -- weak passwords are likely accepted.",
        ))

    return findings


if __name__ == "__main__":
    utils.print_findings("Password Policy", check())
