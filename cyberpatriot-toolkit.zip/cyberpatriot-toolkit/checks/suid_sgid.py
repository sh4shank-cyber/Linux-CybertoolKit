"""
suid_sgid.py -- finds SUID/SGID binaries and flags any outside
config/suid_whitelist.json for manual review. Skips pseudo-filesystems
(proc, sys) so it doesn't waste time or produce noise.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils

SKIP_FS = ["/proc", "/sys", "/run", "/dev"]


def _find_suid_sgid():
    args = ["find", "/"]
    for skip in SKIP_FS:
        args += ["-path", skip, "-prune", "-o"]
    args += ["-type", "f", "(", "-perm", "-4000", "-o", "-perm", "-2000", ")", "-print"]
    code, out, err = utils.run_cmd(args, timeout=60)
    if code not in (0, 1):  # find returns 1 for permission-denied dirs, still usable
        return None, err
    return [line for line in out.splitlines() if line], err


def check():
    findings = []
    whitelist = set(utils.load_config("suid_whitelist.json", {"whitelist": []}).get("whitelist", []))

    paths, err = _find_suid_sgid()
    if paths is None:
        findings.append(utils.finding(utils.MED, "find command failed", err))
        return findings

    for path in paths:
        if path in whitelist:
            continue
        try:
            st = os.stat(path)
        except OSError:
            continue
        bits = []
        if st.st_mode & 0o4000:
            bits.append("SUID")
        if st.st_mode & 0o2000:
            bits.append("SGID")
        findings.append(utils.finding(
            utils.HIGH, f"Unexpected {'/'.join(bits)} binary: {path}",
            "Not in config/suid_whitelist.json. Verify it's supposed to be set, "
            f"then run: chmod u-s,g-s {path}  (only if it shouldn't have the bit)",
        ))

    if not os.access("/", os.R_OK) or utils.is_root() is False:
        findings.append(utils.finding(
            utils.INFO, "Some directories may have been skipped",
            "Run as root/sudo for a complete filesystem scan.",
        ))

    return findings


if __name__ == "__main__":
    utils.print_findings("SUID / SGID Binaries", check())
