"""
updates.py -- reports how many package updates are available. Note:
most CyberPatriot images run with no internet access, so `apt update`
itself may fail -- that's expected and reported as INFO, not an error
in your setup.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils


def _detect_pkg_manager():
    for mgr, probe in (("apt", "apt"), ("dnf", "dnf"), ("yum", "yum"), ("pacman", "pacman")):
        code, _, _ = utils.run_cmd(["which", probe])
        if code == 0:
            return mgr
    return None


def check():
    findings = []
    mgr = _detect_pkg_manager()
    if mgr is None:
        findings.append(utils.finding(utils.INFO, "No known package manager found on PATH"))
        return findings

    if mgr == "apt":
        code, out, err = utils.run_cmd(["apt", "list", "--upgradable"], timeout=30)
        if code != 0:
            findings.append(utils.finding(
                utils.INFO, "Could not query apt for upgradable packages",
                (err or out).strip()[:300] +
                "\nIf this is 'Unable to connect', the image likely has no internet access -- "
                "confirm with your coach whether updates should come from a local/offline mirror.",
            ))
        else:
            lines = [l for l in out.splitlines() if l and not l.startswith("Listing...")]
            if lines:
                findings.append(utils.finding(
                    utils.MED, f"{len(lines)} package(s) have updates available",
                    "\n".join(lines[:30]) + (f"\n... and {len(lines) - 30} more" if len(lines) > 30 else ""),
                ))
            else:
                findings.append(utils.finding(utils.INFO, "System is up to date (per local apt cache)"))

    elif mgr in ("dnf", "yum"):
        code, out, err = utils.run_cmd([mgr, "check-update"], timeout=30)
        # check-update returns 100 when updates ARE available, 0 when none, 1+ on error
        if code == 100:
            lines = [l for l in out.splitlines() if l.strip() and not l.startswith(("Last metadata", "Obsoleting"))]
            findings.append(utils.finding(
                utils.MED, f"{len(lines)} package line(s) with updates available",
                "\n".join(lines[:30]),
            ))
        elif code == 0:
            findings.append(utils.finding(utils.INFO, "System is up to date (per local cache)"))
        else:
            findings.append(utils.finding(
                utils.INFO, f"Could not run {mgr} check-update",
                (err or out).strip()[:300] + "\nLikely no internet access on the competition image.",
            ))

    elif mgr == "pacman":
        code, out, err = utils.run_cmd(["pacman", "-Qu"], timeout=30)
        if code == 0 and out.strip():
            lines = out.strip().splitlines()
            findings.append(utils.finding(
                utils.MED, f"{len(lines)} package(s) have updates available", "\n".join(lines[:30]),
            ))
        else:
            findings.append(utils.finding(utils.INFO, "System is up to date (per local cache), or no internet access"))

    return findings


if __name__ == "__main__":
    utils.print_findings("Package Updates", check())
