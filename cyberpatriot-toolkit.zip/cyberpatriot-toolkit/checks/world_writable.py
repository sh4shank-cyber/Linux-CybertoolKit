"""
world_writable.py -- finds world-writable files, and world-writable
directories that are missing the sticky bit (the classic CyberPatriot
"anyone can delete anyone's files in /tmp" vulnerability).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils

SKIP_FS = ["/proc", "/sys", "/run", "/dev"]
MAX_REPORTED = 40


def _find_world_writable():
    args = ["find", "/"]
    for skip in SKIP_FS:
        args += ["-path", skip, "-prune", "-o"]
    args += ["(", "-type", "f", "-o", "-type", "d", ")", "-perm", "-0002", "-print"]
    code, out, err = utils.run_cmd(args, timeout=60)
    if code not in (0, 1):
        return None, err
    return [line for line in out.splitlines() if line], err


def check():
    findings = []
    paths, err = _find_world_writable()
    if paths is None:
        findings.append(utils.finding(utils.MED, "find command failed", err))
        return findings

    ww_files, ww_dirs_no_sticky, ww_dirs_ok = [], [], 0
    for path in paths:
        try:
            st = os.stat(path)
        except OSError:
            continue
        if os.path.isdir(path):
            if st.st_mode & 0o1000:  # sticky bit set
                ww_dirs_ok += 1
            else:
                ww_dirs_no_sticky.append(path)
        else:
            ww_files.append(path)

    if ww_files:
        findings.append(utils.finding(
            utils.HIGH, f"{len(ww_files)} world-writable file(s) found",
            "\n".join(ww_files[:MAX_REPORTED]) +
            (f"\n... and {len(ww_files) - MAX_REPORTED} more" if len(ww_files) > MAX_REPORTED else ""),
        ))

    if ww_dirs_no_sticky:
        findings.append(utils.finding(
            utils.HIGH, f"{len(ww_dirs_no_sticky)} world-writable dir(s) without the sticky bit",
            "Anyone can delete/rename anyone else's files in these. Fix with: chmod +t <dir>\n" +
            "\n".join(ww_dirs_no_sticky[:MAX_REPORTED]) +
            (f"\n... and {len(ww_dirs_no_sticky) - MAX_REPORTED} more" if len(ww_dirs_no_sticky) > MAX_REPORTED else ""),
        ))

    if not ww_files and not ww_dirs_no_sticky:
        findings.append(utils.finding(utils.INFO, "No problematic world-writable paths found"))

    return findings


if __name__ == "__main__":
    utils.print_findings("World-Writable Files & Dirs", check())
