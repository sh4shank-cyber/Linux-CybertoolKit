"""
firewall.py -- checks ufw, firewalld, or raw iptables/nftables for an
active, default-deny firewall. Tries each in turn since CyberPatriot
Linux images vary between Debian-family (ufw) and RHEL-family
(firewalld).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils


def _check_ufw():
    code, out, err = utils.run_cmd(["ufw", "status", "verbose"])
    if code != 0:
        return None
    active = "status: active" in out.lower()
    default_deny = "deny (incoming)" in out.lower()
    return {"tool": "ufw", "active": active, "default_deny": default_deny, "raw": out}


def _check_firewalld():
    code, out, err = utils.run_cmd(["firewall-cmd", "--state"])
    if code != 0:
        return None
    active = out.strip().lower() == "running"
    return {"tool": "firewalld", "active": active, "default_deny": None, "raw": out}


def _check_iptables():
    code, out, err = utils.run_cmd(["iptables", "-L", "INPUT", "-n"])
    if code != 0:
        return None
    has_rules = len([l for l in out.splitlines() if l and not l.startswith(("Chain", "target"))]) > 0
    default_deny = "policy DROP" in out or "policy REJECT" in out
    return {"tool": "iptables", "active": has_rules or default_deny, "default_deny": default_deny, "raw": out}


def check():
    findings = []

    result = _check_ufw() or _check_firewalld() or _check_iptables()

    if result is None:
        findings.append(utils.finding(
            utils.HIGH, "No firewall tool found (ufw / firewalld / iptables)",
            "Install and enable one: `sudo apt install ufw && sudo ufw enable`",
        ))
        return findings

    tool = result["tool"]
    if not result["active"]:
        findings.append(utils.finding(
            utils.HIGH, f"Firewall ({tool}) is installed but not active",
            "Enable it, e.g. `sudo ufw enable` or `sudo systemctl enable --now firewalld`.",
        ))
    elif result["default_deny"] is False:
        findings.append(utils.finding(
            utils.MED, f"Firewall ({tool}) is active but default policy isn't deny",
            "Set a default-deny incoming policy, e.g. `sudo ufw default deny incoming`.",
        ))
    else:
        findings.append(utils.finding(
            utils.INFO, f"Firewall ({tool}) is active", ""
        ))

    return findings


if __name__ == "__main__":
    utils.print_findings("Firewall", check())
