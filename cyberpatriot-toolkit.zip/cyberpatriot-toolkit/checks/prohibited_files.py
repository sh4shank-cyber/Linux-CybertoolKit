"""
prohibited_files.py -- walks the directories in
config/prohibited_files.json looking for banned file extensions and
filenames matching known hacking-tool keywords. CyberPatriot scores
finding (and, once identified, removing) these.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils

MAX_REPORTED = 50
DEFAULT_CFG = {
    "scan_dirs": ["/home", "/root", "/tmp"],
    "prohibited_extensions": [],
    "prohibited_name_keywords": [],
}


def check():
    findings = []
    cfg = utils.load_config("prohibited_files.json", DEFAULT_CFG)
    scan_dirs = cfg.get("scan_dirs", [])
    extensions = tuple(e.lower() for e in cfg.get("prohibited_extensions", []))
    keywords = [k.lower() for k in cfg.get("prohibited_name_keywords", [])]

    hits_ext, hits_kw = [], []
    for base in scan_dirs:
        if not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base, onerror=lambda e: None):
            for fname in files:
                lower = fname.lower()
                full = os.path.join(root, fname)
                if extensions and lower.endswith(extensions):
                    hits_ext.append(full)
                if any(kw in lower for kw in keywords):
                    hits_kw.append(full)

    if hits_ext:
        findings.append(utils.finding(
            utils.MED, f"{len(hits_ext)} file(s) with a prohibited extension",
            "\n".join(hits_ext[:MAX_REPORTED]) +
            (f"\n... and {len(hits_ext) - MAX_REPORTED} more" if len(hits_ext) > MAX_REPORTED else ""),
        ))
    if hits_kw:
        findings.append(utils.finding(
            utils.HIGH, f"{len(hits_kw)} file(s) matching a hacking-tool keyword",
            "\n".join(hits_kw[:MAX_REPORTED]) +
            (f"\n... and {len(hits_kw) - MAX_REPORTED} more" if len(hits_kw) > MAX_REPORTED else ""),
        ))
    if not hits_ext and not hits_kw:
        findings.append(utils.finding(utils.INFO, "No prohibited files found in configured directories"))

    return findings


if __name__ == "__main__":
    utils.print_findings("Prohibited Files", check())
