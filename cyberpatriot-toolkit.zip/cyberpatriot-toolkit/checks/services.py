"""
services.py -- lists enabled systemd services, flags known-bad ones
(config/expected_services.json -> should_never_run) and reports any
required service (should_be_enabled) that isn't on.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils

DEFAULT_CFG = {"should_be_enabled": [], "should_never_run": []}


def _enabled_services():
    code, out, err = utils.run_cmd(["systemctl", "list-unit-files", "--type=service", "--state=enabled", "--no-legend"])
    if code != 0:
        return None, err
    services = []
    for line in out.splitlines():
        name = line.split()[0] if line.split() else ""
        if name.endswith(".service"):
            services.append(name[: -len(".service")])
    return services, ""


def _is_active(name):
    code, out, err = utils.run_cmd(["systemctl", "is-active", name])
    return out.strip() == "active"


def check():
    findings = []
    cfg = utils.load_config("expected_services.json", DEFAULT_CFG)
    should_be_enabled = set(cfg.get("should_be_enabled", []))
    should_never_run = set(cfg.get("should_never_run", []))

    enabled, err = _enabled_services()
    if enabled is None:
        findings.append(utils.finding(utils.MED, "systemctl not available", err))
        return findings

    enabled_set = set(enabled)

    for bad in should_never_run:
        if bad in enabled_set or _is_active(bad):
            findings.append(utils.finding(
                utils.HIGH, f"Prohibited service is enabled/running: {bad}",
                f"Disable it: sudo systemctl disable --now {bad}",
            ))

    for req in should_be_enabled:
        if req not in enabled_set:
            findings.append(utils.finding(
                utils.MED, f"Required service is not enabled: {req}",
                f"Enable it: sudo systemctl enable --now {req}",
            ))

    return findings


if __name__ == "__main__":
    utils.print_findings("Enabled Services", check())
