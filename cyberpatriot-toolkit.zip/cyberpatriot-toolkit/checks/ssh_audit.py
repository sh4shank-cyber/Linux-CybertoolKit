"""
ssh_audit.py -- checks sshd_config for risky settings and reports
which accounts have SSH keys authorized to log in as them (a common
way a planted backdoor persists even after passwords are changed).
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils

SSHD_CONFIG = "/etc/ssh/sshd_config"

EXPECTED = {
    "PermitRootLogin": ("no", utils.HIGH),
    "PasswordAuthentication": ("no", utils.LOW),  # LOW: many scenarios require password auth to stay on
    "PermitEmptyPasswords": ("no", utils.HIGH),
    "X11Forwarding": ("no", utils.LOW),
    "Protocol": ("2", utils.HIGH),
}


def _parse_sshd_config():
    if not os.path.exists(SSHD_CONFIG):
        return None
    values = {}
    with open(SSHD_CONFIG) as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(None, 1)
            if len(parts) == 2:
                key, val = parts
                values.setdefault(key, val.strip())
    return values


def _home_dirs():
    dirs = []
    try:
        with open("/etc/passwd") as fh:
            for line in fh:
                parts = line.strip().split(":")
                if len(parts) >= 6:
                    dirs.append((parts[0], parts[5]))
    except OSError:
        pass
    return dirs


def check():
    findings = []

    cfg = _parse_sshd_config()
    if cfg is None:
        findings.append(utils.finding(utils.MED, f"{SSHD_CONFIG} not found", "Is sshd installed?"))
    else:
        for key, (expected, severity) in EXPECTED.items():
            actual = cfg.get(key)
            if actual is None:
                findings.append(utils.finding(
                    utils.LOW, f"{key} not explicitly set in sshd_config",
                    f"Distro default may not match the expected value ({expected}). Set it explicitly.",
                ))
            elif actual.lower() != expected.lower():
                findings.append(utils.finding(
                    severity, f"{key} is '{actual}', expected '{expected}'",
                ))

    for user, home in _home_dirs():
        auth_keys = os.path.join(home, ".ssh", "authorized_keys")
        if os.path.isfile(auth_keys):
            try:
                with open(auth_keys) as fh:
                    lines = [l for l in fh if l.strip() and not l.strip().startswith("#")]
                findings.append(utils.finding(
                    utils.MED if user != "root" else utils.HIGH,
                    f"{user} has {len(lines)} SSH key(s) authorized to log in",
                    f"{auth_keys} -- confirm every key belongs to an approved administrator.",
                ))
            except OSError:
                pass

    return findings


if __name__ == "__main__":
    utils.print_findings("SSH Configuration", check())
