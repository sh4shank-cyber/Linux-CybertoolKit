"""
users_groups.py -- flags unauthorized accounts, stray UID 0 accounts,
and unexpected sudo/admin membership.

Fill in config/authorized_users.json from the scenario README first.
Run as root to also see lock status from /etc/shadow.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils

ADMIN_GROUPS = {"sudo", "wheel", "admin"}


def _read_passwd():
    users = {}
    with open("/etc/passwd") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(":")
            if len(parts) < 7:
                continue
            name, _, uid, gid, _, home, shell = parts[:7]
            users[name] = {"uid": int(uid), "gid": int(gid), "home": home, "shell": shell}
    return users


def _read_group():
    groups = {}
    with open("/etc/group") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(":")
            if len(parts) < 4:
                continue
            name, _, gid, members = parts[:4]
            groups[name] = {
                "gid": int(gid),
                "members": [m for m in members.split(",") if m],
            }
    return groups


def _locked_accounts():
    """Returns set of usernames with a '!' or '*' (locked/no-password) hash,
    or None if /etc/shadow isn't readable."""
    if not os.access("/etc/shadow", os.R_OK):
        return None
    locked, empty_pw = set(), set()
    try:
        with open("/etc/shadow") as fh:
            for line in fh:
                parts = line.strip().split(":")
                if len(parts) < 2:
                    continue
                name, pw_hash = parts[0], parts[1]
                if pw_hash in ("", ):
                    empty_pw.add(name)
                elif pw_hash.startswith("!") or pw_hash.startswith("*"):
                    locked.add(name)
    except OSError:
        return None
    return {"locked": locked, "empty_pw": empty_pw}


def check():
    findings = []
    cfg = utils.load_config(
        "authorized_users.json",
        {"authorized_users": ["root"], "authorized_admins": ["root"]},
    )
    authorized_users = set(cfg.get("authorized_users", []))
    authorized_admins = set(cfg.get("authorized_admins", []))

    users = _read_passwd()
    groups = _read_group()

    # Unauthorized / unexpected accounts (skip standard system accounts under 1000
    # unless they have UID 0, since distros ship dozens of service accounts).
    for name, info in users.items():
        if info["uid"] == 0 and name != "root":
            findings.append(utils.finding(
                utils.HIGH, f"UID 0 account that isn't root: {name}",
                "Any account with UID 0 has full root privileges regardless of name.",
            ))
            continue
        if info["uid"] >= 1000 and name not in authorized_users and name != "nobody":
            findings.append(utils.finding(
                utils.HIGH, f"Unauthorized user account: {name}",
                f"UID {info['uid']}, shell {info['shell']}. Not in config/authorized_users.json.",
            ))

    # Authorized users that are missing entirely
    for name in authorized_users:
        if name not in users:
            findings.append(utils.finding(
                utils.MED, f"Expected user account is missing: {name}",
                "Listed as authorized in config but not present on the system.",
            ))

    # Admin/sudo membership
    admin_members = set()
    for g in ADMIN_GROUPS:
        if g in groups:
            admin_members.update(groups[g]["members"])
    for name in admin_members:
        if name not in authorized_admins:
            findings.append(utils.finding(
                utils.HIGH, f"Unauthorized admin/sudo privileges: {name}",
                f"Member of {', '.join(g for g in ADMIN_GROUPS if g in groups and name in groups[g]['members'])}.",
            ))
    for name in authorized_admins:
        if name not in admin_members and name in users:
            findings.append(utils.finding(
                utils.LOW, f"Expected admin is missing sudo/wheel membership: {name}",
                "Listed as an authorized admin but not in any admin group.",
            ))

    # Shells that shouldn't grant a login (nologin/false expected for service accounts)
    for name, info in users.items():
        if info["uid"] >= 1000 and name in authorized_users:
            if info["shell"] in ("/usr/sbin/nologin", "/bin/false", "/sbin/nologin"):
                findings.append(utils.finding(
                    utils.LOW, f"Authorized user {name} has a no-login shell",
                    f"Shell is {info['shell']} -- confirm this is intended for this account.",
                ))

    shadow_info = _locked_accounts()
    if shadow_info is None:
        findings.append(utils.require_root_notice("users_groups"))
    else:
        for name in shadow_info["empty_pw"]:
            if name in users and users[name]["shell"] not in (
                "/usr/sbin/nologin", "/bin/false", "/sbin/nologin",
            ):
                findings.append(utils.finding(
                    utils.HIGH, f"Account with an empty password: {name}",
                    "Can log in with no password at all -- set a password or lock the account.",
                ))

    return findings


if __name__ == "__main__":
    utils.print_findings("Users & Groups", check())
