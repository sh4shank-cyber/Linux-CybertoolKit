"""
network_ports.py -- lists listening TCP/UDP ports and flags anything
not in the expected list. This is also the check baseline.py snapshots
for its diff mode, since new listeners appearing mid-round are a
classic sign of a planted backdoor.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils

DEFAULT_EXPECTED_PORTS = {22}  # ssh; override via config/expected_services.json "expected_ports"

RISKY_PORTS = {
    21: "FTP", 23: "Telnet", 25: "SMTP (unless mail server required)",
    69: "TFTP", 111: "rpcbind", 512: "rexec", 513: "rlogin", 514: "rsh",
    2049: "NFS", 6667: "IRC (common backdoor/C2 port)", 31337: "classic backdoor port",
}


def _proc_net_fallback():
    """Last-resort listener list parsed straight from /proc/net/{tcp,udp}[6]
    when neither ss nor netstat is installed. Doesn't resolve process names."""
    listeners = []
    sources = [
        ("tcp", "/proc/net/tcp", True), ("tcp", "/proc/net/tcp6", True),
        ("udp", "/proc/net/udp", False), ("udp", "/proc/net/udp6", False),
    ]
    for proto, path, needs_listen_state in sources:
        if not os.path.exists(path):
            continue
        with open(path) as fh:
            next(fh, None)  # header
            for line in fh:
                cols = line.split()
                if len(cols) < 4:
                    continue
                local, rem, state = cols[1], cols[2], cols[3]
                port = int(local.split(":")[1], 16)
                if needs_listen_state:
                    if state.upper() != "0A":  # TCP_LISTEN
                        continue
                else:
                    if rem.split(":")[1] != "0000":  # UDP socket in use, not just bound
                        continue
                listeners.append((proto, port, "unknown (install `ss`/iproute2 for process names)"))
    return listeners


def list_listeners():
    """Returns list of (proto, port, process) using `ss`, falling back to
    `netstat`, falling back to parsing /proc/net directly."""
    code, out, err = utils.run_cmd(["ss", "-tulnp"])
    if code != 0:
        code, out, err = utils.run_cmd(["netstat", "-tulnp"])
        if code != 0:
            fallback = _proc_net_fallback()
            if fallback:
                return fallback, ""
            return None, err

    listeners = []
    for line in out.splitlines():
        if not line or line.lower().startswith(("netid", "proto", "active")):
            continue
        proto = "tcp" if line.lower().startswith("tcp") else ("udp" if line.lower().startswith("udp") else None)
        if not proto:
            continue
        m = re.search(r"[\d.\[\]:*]+:(\d+)\s", line)
        if not m:
            continue
        port = int(m.group(1))
        proc_m = re.search(r'users:\(\("([^"]+)"', line) or re.search(r'"([^"]+)"', line)
        process = proc_m.group(1) if proc_m else "unknown"
        listeners.append((proto, port, process))
    return listeners, err


def check():
    findings = []
    cfg = utils.load_config("expected_services.json", {})
    expected_ports = set(cfg.get("expected_ports", [])) or DEFAULT_EXPECTED_PORTS

    listeners, err = list_listeners()
    if listeners is None:
        findings.append(utils.finding(utils.MED, "Could not list listening ports", err))
        return findings

    seen_ports = set()
    for proto, port, process in sorted(set(listeners), key=lambda x: x[1]):
        seen_ports.add(port)
        if port in RISKY_PORTS:
            findings.append(utils.finding(
                utils.HIGH, f"Listening on high-risk port {port}/{proto} ({RISKY_PORTS[port]})",
                f"Process: {process}",
            ))
        elif port not in expected_ports:
            findings.append(utils.finding(
                utils.MED, f"Unexpected listener on port {port}/{proto}",
                f"Process: {process}. Add to config/expected_services.json 'expected_ports' if this is legitimate.",
            ))

    missing = expected_ports - seen_ports
    for port in missing:
        findings.append(utils.finding(
            utils.LOW, f"Expected port {port} is not listening",
            "Listed as expected but no process is bound to it.",
        ))

    if not utils.is_root():
        findings.append(utils.require_root_notice("network_ports"))

    return findings


if __name__ == "__main__":
    utils.print_findings("Listening Ports", check())
