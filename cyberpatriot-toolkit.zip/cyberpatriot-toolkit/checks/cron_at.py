"""
cron_at.py -- dumps every cron and at job on the system. Planted
backdoors love hiding here, so this check surfaces *everything* for
manual review (INFO) and separately flags entries containing
suspicious keywords (HIGH) so those jump out first.
"""
import glob
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils

SUSPICIOUS_KEYWORDS = [
    "curl", "wget", "nc ", "ncat", "netcat", "/dev/tcp/", "base64 -d",
    "chmod +s", "chmod 4755", "chmod u+s", "bash -i", "python -c", "perl -e",
    "0.0.0.0", "reverse", "socat",
]

# Files in these follow "min hour day month weekday user command" syntax.
CRONTAB_FORMAT_PATHS = ["/etc/crontab", "/etc/cron.d"]

# Files in these are whole executable scripts run by run-parts on a schedule
# implied by the directory name -- list them by name, don't dump every line.
RUN_PARTS_DIRS = ["/etc/cron.hourly", "/etc/cron.daily", "/etc/cron.weekly", "/etc/cron.monthly"]

USER_CRONTAB_DIRS = [
    "/var/spool/cron/crontabs",  # Debian/Ubuntu
    "/var/spool/cron",           # RHEL/CentOS
]


def _read_file_lines(path):
    try:
        with open(path) as fh:
            return [l.rstrip("\n") for l in fh if l.strip() and not l.strip().startswith("#")]
    except (OSError, UnicodeDecodeError):
        return []


def _collect_system_cron():
    """Returns (entries, script_entries): scheduled one-liners, and
    (path, first-matching-suspicious-line-or-None) for run-parts scripts."""
    entries = []
    for path in CRONTAB_FORMAT_PATHS:
        if os.path.isfile(path):
            for line in _read_file_lines(path):
                entries.append((path, line))
        elif os.path.isdir(path):
            for fname in os.listdir(path):
                full = os.path.join(path, fname)
                if os.path.isfile(full):
                    for line in _read_file_lines(full):
                        entries.append((full, line))

    script_entries = []
    for d in RUN_PARTS_DIRS:
        if not os.path.isdir(d):
            continue
        for fname in sorted(os.listdir(d)):
            full = os.path.join(d, fname)
            if not os.path.isfile(full):
                continue
            content = "\n".join(_read_file_lines(full)).lower()
            hit = next((kw for kw in SUSPICIOUS_KEYWORDS if kw in content), None)
            script_entries.append((full, hit))
    return entries, script_entries


def _collect_user_crontabs():
    entries = []
    for d in USER_CRONTAB_DIRS:
        if not os.path.isdir(d):
            continue
        for path in glob.glob(os.path.join(d, "*")):
            user = os.path.basename(path)
            for line in _read_file_lines(path):
                entries.append((f"crontab({user})", line))
    return entries


def _collect_at_jobs():
    code, out, err = utils.run_cmd(["atq"])
    if code != 0:
        return []
    jobs = []
    for line in out.splitlines():
        if line.strip():
            jobs.append(("atq", line.strip()))
    return jobs


def check():
    findings = []
    crontab_entries, script_entries = _collect_system_cron()
    all_entries = crontab_entries + _collect_user_crontabs() + _collect_at_jobs()

    if not all_entries and not script_entries:
        findings.append(utils.finding(utils.INFO, "No cron/at entries found (or none readable without root)"))
        if not utils.is_root():
            findings.append(utils.require_root_notice("cron_at"))
        return findings

    suspicious, normal = [], []
    for source, line in all_entries:
        lower = line.lower()
        if any(kw in lower for kw in SUSPICIOUS_KEYWORDS):
            suspicious.append(f"{source}: {line}")
        else:
            normal.append(f"{source}: {line}")

    for path, hit in script_entries:
        if hit:
            suspicious.append(f"{path}: contains suspicious keyword '{hit}'")
        else:
            normal.append(f"{path} (run-parts script)")

    if suspicious:
        findings.append(utils.finding(
            utils.HIGH, f"{len(suspicious)} cron/at entr(y/ies) contain suspicious keywords",
            "\n".join(suspicious),
        ))
    findings.append(utils.finding(
        utils.INFO, f"{len(normal)} other cron/at entr(y/ies) -- review manually, content is scenario-specific",
        "\n".join(normal[:60]) + (f"\n... and {len(normal) - 60} more" if len(normal) > 60 else ""),
    ))

    if not utils.is_root():
        findings.append(utils.require_root_notice("cron_at"))

    return findings


if __name__ == "__main__":
    utils.print_findings("Cron & At Jobs", check())
