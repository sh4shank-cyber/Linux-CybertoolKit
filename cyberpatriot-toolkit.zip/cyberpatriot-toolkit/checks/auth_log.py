"""
auth_log.py -- summarizes /var/log/auth.log (Debian/Ubuntu) or
/var/log/secure (RHEL/CentOS) for failed logins, sudo usage, and
account changes, so you're not scrolling raw logs mid-round.
"""
import os
import re
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import utils

LOG_CANDIDATES = ["/var/log/auth.log", "/var/log/secure"]
MAX_SHOWN = 15
FAILED_LOGIN_ALERT_THRESHOLD = 10


def _find_log():
    for path in LOG_CANDIDATES:
        if os.path.isfile(path):
            return path
    return None


def check():
    findings = []
    log_path = _find_log()
    if log_path is None:
        findings.append(utils.finding(
            utils.INFO, "No auth log found",
            "Checked: " + ", ".join(LOG_CANDIDATES) + ". May need root, or logs may rotate/compress.",
        ))
        return findings

    try:
        with open(log_path, errors="replace") as fh:
            lines = fh.readlines()
    except OSError as e:
        findings.append(utils.finding(utils.MED, f"Could not read {log_path}", str(e)))
        return findings

    failed_by_user = Counter()
    new_users = []
    sudo_events = []
    accepted = []

    for line in lines:
        m = re.search(r"Failed password for (invalid user )?(\S+) from (\S+)", line)
        if m:
            failed_by_user[m.group(2)] += 1
            continue
        m = re.search(r"Accepted password for (\S+) from (\S+)", line)
        if m:
            accepted.append(f"{m.group(1)} from {m.group(2)}")
            continue
        if "useradd" in line.lower() and "new user" in line.lower():
            new_users.append(line.strip())
            continue
        if re.search(r"\bsudo:.*COMMAND=", line):
            sudo_events.append(line.strip())

    if failed_by_user:
        total = sum(failed_by_user.values())
        top = failed_by_user.most_common(MAX_SHOWN)
        sev = utils.HIGH if total >= FAILED_LOGIN_ALERT_THRESHOLD else utils.MED
        findings.append(utils.finding(
            sev, f"{total} failed login attempt(s) across {len(failed_by_user)} username(s)",
            "\n".join(f"{u}: {c}" for u, c in top),
        ))

    if new_users:
        findings.append(utils.finding(
            utils.MED, f"{len(new_users)} account-creation event(s) in the log",
            "\n".join(new_users[-MAX_SHOWN:]),
        ))

    if sudo_events:
        findings.append(utils.finding(
            utils.INFO, f"{len(sudo_events)} sudo command(s) logged -- review for anything unexpected",
            "\n".join(sudo_events[-MAX_SHOWN:]),
        ))

    if accepted:
        findings.append(utils.finding(
            utils.INFO, f"{len(accepted)} successful password login(s)",
            "\n".join(accepted[-MAX_SHOWN:]),
        ))

    if not any([failed_by_user, new_users, sudo_events, accepted]):
        findings.append(utils.finding(utils.INFO, f"No notable events found in {log_path}"))

    if not utils.is_root() and not os.access(log_path, os.R_OK):
        findings.append(utils.require_root_notice("auth_log"))

    return findings


if __name__ == "__main__":
    utils.print_findings("Auth Log Summary", check())
